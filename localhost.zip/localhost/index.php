
<?php // Доделать проверку на занятость никнейма (https://htmlweb.ru/php/example/avtorizacija2.php)
    require_once 'settings/db.php';
    $connection = connect();

    if(isset ($_POST ['btn'])) {
        $login = $_POST['login'];
        $denzel = mysqli_query($connection, "SELECT id FROM users WHERE username='".mysqli_real_escape_string($connection, $login)."'");

        if($login != ''){
            $query = "INSERT INTO `users` (`username`) VALUES ('$login')";
            $recive = mysqli_query($connection, $query);
            header('Location: http://' . $_SERVER['SERVER_NAME'] . '/chat.php');
        }
        if(mysqli_num_rows($denzel) > 0)
        {
            echo "<script>alert('Данный никнейм занят. Попробуйте выбрать другой.')</script>";
        }
        else {
            echo "<script>alert('Произошла ошибка.')</script>";
        }

        /*if(mysqli_num_rows($denzel) > 0)
        {
            echo "<script>alert('Данный никнейм занят. Попробуйте выбрать другой.')</script>";
        }
        if($login == '') {
            echo "<script>alert('Вы не ввели никнейм, а оставили поле пустым. Введите никнейм.')</script>";
        }
        else {
            $query = "INSERT INTO `users` (`username`) VALUES ('$login')";
            $recive = mysqli_query($connection, $query);
            header('Location: http://' . $_SERVER['SERVER_NAME'] . '/chat.php');
        }*/
    }
    
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Начальная страница</title>
</head>
<body>
    <center>
    <p>Регистрация</p>
    <form action="" method="post">
    <input type="text" placeholder="Введите никнейм" name="login"><br>
    <br><input type="submit" name="btn" value="Зарегистрироваться">
    </form>
    </center>
</body>
</html>