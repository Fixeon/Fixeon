<?php
    require_once 'settings/db.php';
    $connection = connect();

    if(isset ($_POST ['btn'])) {
        $login = $_POST['login'];

        if($login == NULL) {
            echo "<script>alert('Вы не ввели никнейм, а оставили поле пустым. Введите никнейм.')</script>";
        }
        elseif($login == $recive) {

            $query = "SELECT `username`, `id` FROM `users` WHERE `username` = '$serch'";

            $recive = mysqli_query($connection, $query);
            echo $recive;

            //$query = "SELECT * WHERE `username` = '$login' FROM `users`";
            //$query = "SELECT * FROM `users` WHERE `username` = '$login'";
            //header('Location: http://' . $_SERVER['SERVER_NAME'] . '/chat.php');
            //$login = mysqli_real_escape_string($connection, $login);
        }
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
</head>
<body>
<center>
    <p>Авторизация</p>
    <form action="" method="post">
    <input type="text" placeholder="Введите никнейм" name="login"><br>
    <br><input type="submit" name="btn" value="Авторизоваться">
    </form>
    </center>
</body>
</html>