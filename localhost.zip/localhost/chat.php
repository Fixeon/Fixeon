<?php
echo "чат";
?>